//
//  SignInVCViewController.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit
import Firebase

// Manages Sign-In page
class SignInVCViewController: UIViewController {

    // Outlets
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // Log the user-in
    @IBAction func signInPressed(_ sender: UIButton) {
        
        // Validate inputs
        guard let email = emailTF.text else { return }
        guard let pass = passTF.text else { return }
        
        // Log the user-in, or notify them of the error
        Auth.auth().signIn(withEmail: email, password: pass) { authResult, error in
            if let e = error {
                let ac = UIAlertController(title: "Warning", message: "\(e.localizedDescription)", preferredStyle: .alert)
                ac.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
                self.present(ac, animated: true, completion: nil)
            }
            else {
                // Go to next screen if log-in is successful
                self.performSegue(withIdentifier: "toHome", sender: self)
            }
        }
    }
    
}
