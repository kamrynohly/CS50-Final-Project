//
//  CommentsVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/5/21.
//

import UIKit
import Firebase

// Comments Page
class CommentsVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate{

    // Outlets & Global Variables with Custom Class
    var commentsArray = [Comment]()
    var contentPathway : DatabaseReference!

    @IBOutlet weak var commentsTable: UITableView!
    @IBOutlet weak var contentView: UITextView!
    
    // Load Screen
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set Delegates and Initial Attributes
        commentsTable.delegate = self
        commentsTable.dataSource = self
        contentView.delegate = self
        contentView.text = "Comment here!"
        contentView.textColor = UIColor.lightGray
        
        // Get Data and Load Tables
        retrieveData()
    }
    
    // Add placeholder to text view
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Comment here!"
            textView.textColor = UIColor.lightGray
        }
    }
    
    // Table View Functions
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return commentsArray.count
    }

    // Create the cell and load data from array of comments
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Make object of custom class CommentCell
        let cell = tableView.dequeueReusableCell(withIdentifier: "commentCell", for: indexPath) as! CommentCell
        
        // Update UI with data
        cell.contentLabel.text = commentsArray[indexPath.row].content
        cell.addImage(reference: commentsArray[indexPath.row].photoRef)
        cell.nameLabel.text = commentsArray[indexPath.row].name
        
        return cell
    }
    
    // Add new comment to Firebase
    @IBAction func postCommentPressed(_ sender: UIButton) {
        
        // Add comment to Firebase & validate
        guard let commentPosted = contentView.text else {return}
        
        // First, find out who is posting the comment
        let userID = Auth.auth().currentUser?.uid
        let posterRef = Database.database().reference().child("users").child(userID!).child("personalInfo")
        
        var name = ""
        
        // Get name -> Upload it with comment to Firebase
        posterRef.observeSingleEvent(of: .value) { (snapshot) in
            
            // Validate first
            guard let snapshotInfo = snapshot.value as? [String:String] else {return}
            
            if snapshotInfo["name"] != nil {
                name = snapshotInfo["name"]!
            }
            else {
                name = "user unknown"
            }
            
            let commentDictionary = ["comment": commentPosted, "userID": userID, "name": name]

            // Takes pathway of the original post, saves comment as child of that post
            self.contentPathway.child("commentsOfPost").childByAutoId().setValue(commentDictionary)
        }
    }
    
    // Load data from Firebase
    func retrieveData() {
        
        // Using given pathway, get pre-existing comments
        contentPathway.child("commentsOfPost").observe(.value) { (snapshot) in
            
            // Reset array
            self.commentsArray.removeAll()
            
            // Check values
            guard let values = snapshot.value as? [String : NSDictionary] else { return }
            
            // Iterate through, adding a new Comment object for each
            for key in values {
                if key.value["comment"] != nil {
                    // Validate
                    guard let content = key.value["comment"] as? String else { return }
                    guard let name = key.value["name"] as? String else { return }
                    guard let userID = key.value["userID"] as? String else { return }
                    
                    // Add comment
                    let addComment = Comment(contentInput: content, nameInput: name, userPic: Storage.storage().reference().child("displayUsers").child(userID).child("profileImage"))
                    self.commentsArray.append(addComment)                }
                else {
                    print("Something went wrong loading the event data")
                }
               
                // Reload data
                self.commentsTable.reloadData()
            }
        }
    }
    
}

