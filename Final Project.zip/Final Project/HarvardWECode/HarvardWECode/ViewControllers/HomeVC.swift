//
//  HomeVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit
import Firebase
import FirebaseStorageUI
import SDWebImage

// Profile Page of User
class HomeVC: UIViewController {

    // Outlets & Global Variables
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    @IBOutlet weak var schoolLabel: UILabel!
    @IBOutlet weak var bioLabel: UILabel!
    
    var qrLink = ""
    var social = ""
    var linkedin = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load our Firebase data
        retrieveData()
    }
    
    // Send data to barcode page
    @IBAction func connectBarcodePressed(_ sender: UIButton) {
        
        // Validate links exist
        if sender.titleLabel?.text == "Click to Connect on Socials" && social != "" {
            qrLink = social
        }
        else if sender.titleLabel?.text == "Click to Connect on LinkedIn" && linkedin != "" {
            qrLink = linkedin
        }
        
        // As long as we have a link, then go to next page, otherwise do nothing
        if qrLink != "" {
            performSegue(withIdentifier: "goToQR", sender: self)
        }
        
    }
    
    // Get data from Firebase
    func retrieveData() {
        
        // Search by userID
        let userID = Auth.auth().currentUser?.uid
        let userPersonalRef = Database.database().reference().child("users").child(userID!).child("personalInfo")
        
        userPersonalRef.observeSingleEvent(of: .value) { (snapshot) in
            
            // This is a LOT of data validating, since I need to make sure nothing in the database went wrong
            // Thus, I downcast the values before updating UI in order to not crash the app if a value is missing
            guard let values = snapshot.value as? [String: String] else { return }
            
            if let name = values["name"] {
                self.nameLabel.text = name
            }
            else {
                print("Something went wrong loading the personal data")
            }
            
            if let bio = values["bio"] {
                if bio != "" {
                    self.bioLabel.text = "About me: " + bio
                }
                else {
                    self.bioLabel.text = "Add a bio!"
                }
            }
            
            if let school = values["university"] {
                self.schoolLabel.text = "University: " + school
            }
            
            // Add our image too!
            self.addImage(reference: Storage.storage().reference().child("displayUsers").child(userID!).child("profileImage"))
            
            if let socialLink = values["social"] {
                self.social = socialLink
            }
            if let linkedInLink = values["social"] {
                self.linkedin = linkedInLink
            }
        }
        
    }
    
    // Log user out
    @IBAction func logoutPressed(_ sender: Any) {
     
        // Present log-out alert
        let actionSheet = UIAlertController(title: nil, message: "Are you sure you want to log out?", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        // Alerts use closures -> style is important in Swift for this part! Thus, it looks a little weird!
        actionSheet.addAction(UIAlertAction(title: "Log Out", style: .destructive, handler: { (error) in
            
            // Firebase logout, or print error
            let firebaseAuth = Auth.auth()
            do {
                try firebaseAuth.signOut()
                self.performSegue(withIdentifier: "goToFirst", sender: self)
            }
            catch let signOutError as NSError {
                print("Error signing out: %@", signOutError)
            }
        }))
        present(actionSheet, animated: true)

    }
    
    // Load image with FirebaseUI
    func addImage(reference: StorageReference) {
        profilePic.sd_setImage(with: reference, placeholderImage: UIImage(named: "loadingPic"))
        profilePic.layer.cornerRadius = profilePic.frame.height/2
        profilePic.clipsToBounds = true
        profilePic.contentMode = .scaleAspectFill
    }
  
    // Send QR link to next VC destination if it is QRCodeVC
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let nextVC = segue.destination as? QRCodeVC {
            nextVC.link = qrLink
        }
    }

}
