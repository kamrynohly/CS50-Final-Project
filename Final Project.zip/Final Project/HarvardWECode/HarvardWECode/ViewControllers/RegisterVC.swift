//
//  RegisterVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit
import Firebase

// Register Page
class RegisterVC: UIViewController {

    // Outlets
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var universityTF: UITextField!
    @IBOutlet weak var passTF: UITextField!
    @IBOutlet weak var confirmPassTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // Register user
    @IBAction func registerPressed(_ sender: UIButton) {
        
        // Validate inputs
        guard let email = emailTF.text else { return }
        guard let pass = passTF.text else { return }
        guard let university = universityTF.text else { return }
        guard let name = nameTF.text else { return }
        
        // Alert user if passwords do not match, otherwise, register them
        if passTF.text != confirmPassTF.text {
            // Shows the user an alert
            let alertController = UIAlertController(title: "Passwords Do Not Match", message: "Please re-type password", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
        }
        else {
            Auth.auth().createUser(withEmail: email, password: pass) { authResult, error in
                if let e = error {
                    // Show alert of error to user
                    let ac = UIAlertController(title: "Warning", message: "\(e.localizedDescription)", preferredStyle: .alert)
                    ac.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
                    self.present(ac, animated: true, completion: nil)
                } else {
                    // Registration successful, add user info to Firebase
                    let userID = Auth.auth().currentUser?.uid
                    let ref = Database.database().reference().child("users").child(userID!).child("personalInfo")
                    let infoDict = ["university" : university, "name" : name, "userID": userID!, "bio": " "]
                    ref.setValue(infoDict)
                       
                    // For creation of data locations, ignore warnings (relates to Firebase set-up)
                    let messagesRef = Database.database().reference().child("users").child(userID!).child("messages")
                    let eventsRef = Database.database().reference().child("users").child(userID!).child("savedEvents")
                       
                    // Go to next page
                    self.performSegue(withIdentifier: "toHome", sender: self)
                }
            }
        }
    }
    
}
