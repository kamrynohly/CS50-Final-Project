//
//  QRCodeVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit

class QRCodeVC: UIViewController {

    // Outlets and Global Variables
    
    var link = ""
    
    @IBOutlet weak var qrImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    // Update UI with bar code
    override func viewDidAppear(_ animated: Bool) {
        qrImage.image = generateQRCode(from: link)
    }
    
    // Return custom bar code from link, use Swift libraries, then scale QR correctly
    func generateQRCode(from string: String) -> UIImage? {
        
        let data = string.data(using: String.Encoding.ascii)
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let scale = CGAffineTransform(scaleX: 3, y: 3)
            // Validate and return
            if let result = filter.outputImage?.transformed(by: scale) {
                return UIImage(ciImage: result)
            }
        }

        // If problem, then
        return nil
    }

}
