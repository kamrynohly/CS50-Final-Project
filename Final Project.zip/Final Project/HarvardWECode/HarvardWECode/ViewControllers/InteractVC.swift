//
//  InteractVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit
import Firebase

// Interact Page
class InteractVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    // Outlets & Global Variables
    @IBOutlet weak var slider: UISegmentedControl!
    @IBOutlet weak var interactTable: UITableView!
    
    // Used for table
    var interactions = [Interaction]()
    
    // Used for comments
    var name = ""
    var selectedComments = [String]()
    var selectedInteractionPath : DatabaseReference?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set delegates, general Swift requirements
        interactTable.delegate = self
        interactTable.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        // Load data for the selected conversation type
        retrieveData(type: slider.titleForSegment(at: slider.selectedSegmentIndex)!)
    }
    
    // Add a new interaction
    @IBAction func addInteraction(_ sender: Any) {
        
        // Create an alert with a text-field
        let ac = UIAlertController(title: "Leave your message:", message: nil, preferredStyle: .alert)
        ac.addTextField()

        // Add action, when the user submits a non-empty message, then it is saved
        let submitAction = UIAlertAction(title: "Submit", style: .default) { [unowned ac] _ in
            let answer = (ac.textFields![0].text)! as String
            if answer != "" {
                self.saveInteraction(text: answer)
            }
        }
        ac.addAction(submitAction)

        // Show the alert
        present(ac, animated: true)
    }
    
    // Save given interaction to Firebase
    func saveInteraction(text : String) {
        
        // Validate
        guard let type = slider.titleForSegment(at: slider.selectedSegmentIndex) else { return }
           
        // Pathway to update info
        let interactionRef = Database.database().reference().child("community").child(type).childByAutoId()
        let updatedDictionary = ["name": name, "content": text]
        
        // Updates Values
        interactionRef.updateChildValues(updatedDictionary)
        
        // Refresh table
        retrieveData(type: type)
    }
    
    // Choose type of interaction with slider
    @IBAction func chooseType(_ sender: UISegmentedControl) {
        let title = sender.titleForSegment(at: sender.selectedSegmentIndex)!
        
        // When changed, reload data
        retrieveData(type: title)
    }
    
    // Height of Cells
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130.0
    }
    
    // Number of Cells
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return interactions.count
    }
    
    // Create each cell with data
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Use custom class to generate an object of the cell for the table
        let cell = tableView.dequeueReusableCell(withIdentifier: "interactCell", for: indexPath) as! InteractTableViewCell
        
        // Firebase reference of particular cell
        let contentRef = Database.database().reference().child("community").child(slider.titleForSegment(at: slider.selectedSegmentIndex)!).child(interactions[indexPath.row].firebaseID)

        // Add action for when a user wants to comment, takes them to the comments
        cell.addCommentButtonAction = { [unowned self] in
            selectedComments = interactions[indexPath.row].comments
            selectedInteractionPath = contentRef
            performSegue(withIdentifier: "goToComments", sender: self)
        }

        // Validates cells and adds UI updates
        if interactions.count == 0 {
           print("something wrong with loading cells")
        }
        else {
            cell.nameLabel.text = interactions[indexPath.row].name
            cell.contentLabel.text = interactions[indexPath.row].content
        }
        return cell
        
    }
    
    // Load data from Firebase
    func retrieveData(type : String) {
        
        // Database pathway
        let ref = Database.database().reference().child("community").child(type)
        ref.observeSingleEvent(of: .value) { (snapshot) in
            
            // Reset array & validate
            self.interactions.removeAll()
            guard let values = snapshot.value as? [String : NSDictionary] else { return }
            
            // Loop through values
            for item in values {
                if item.value["name"] != nil {
                    
                    // Create object of custom Interaction class, validate, then add to array
                    let new = Interaction(nameInput: item.value["name"] as! String, contentInput: item.value["content"] as! String)
                    new.firebaseID = String(item.key)

                    if let comments = item.value["comments"] {
                        new.comments = comments as! [String]
                    }
                    else {
                        //new.comments = ["no comments yet"]
                    }
                    self.interactions.append(new)
                }
                else {
                    print("Something went wrong loading the schedule data")
                }
            }
            // Reload table
            self.interactTable.reloadData()
        }
        
        // In addition, get user personal name from Firebase for use in comments
        // Database reference
        let userID = Auth.auth().currentUser?.uid
        let personalRef = Database.database().reference().child("users").child(userID!).child("personalInfo")
        personalRef.observeSingleEvent(of: .value) { (snapshot) in
            // Validate & Save name
            guard let values = snapshot.value as? [String: String] else { return }
            if let name = values["name"] {
                self.name = name
            }
            else {
                print("Something went wrong loading the personal data")
            }
        }
    }
    
    // Prepare for showing comments page
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationVC = segue.destination as? CommentsVC {
            destinationVC.contentPathway = selectedInteractionPath
        }
    }

}
