//
//  ViewController.swift
//  HarvardWECode
//
//  Created by Kamryn Ohly on 12/2/21.
//

import UIKit

// Default Swift Code - Loads 1st page of app
class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}

