//
//  ForYouVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit

// For You Page
class ForYouVC: UIViewController {

    // Basic Swift function -> loads the page
    // This is the general set-up of all View Controllers!
    // No additional code is necessary for this feature as of yet!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
