//
//  ScheduleVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit
import Firebase

// Schedule Page
class ScheduleVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // Outlets & Array of Events
    @IBOutlet weak var slider: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    
    var schedule = [Event]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set delegates for our table
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        // Get the Firebase data for the chosen day of events
        retrieveData(day: slider.titleForSegment(at: slider.selectedSegmentIndex)!)
    }
    
    // When the user changes the date, reload the data
    @IBAction func dateChanged(_ sender: UISegmentedControl) {
        let title = sender.titleForSegment(at: sender.selectedSegmentIndex)!
        retrieveData(day: title)
    }
    
    // Height of Cells
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
    
    // Number of Cells
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return schedule.count
    }
    
    // Generate each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Using my custom design and structure, generate an object of the cell class
        let cell = tableView.dequeueReusableCell(withIdentifier: "scheduleCell", for: indexPath) as! ScheduleCellTableViewCell

        // If there is nothing in the schedule, print an error
        if schedule.count == 0 {
           print("something wrong")
        }
        // Otherwise, set the UI with the information
        else {
            cell.location.text = schedule[indexPath.row].location
            cell.title.text = schedule[indexPath.row].name
            cell.desc.text = schedule[indexPath.row].description
            cell.time.text = "\(schedule[indexPath.row].startTime)-\(schedule[indexPath.row].endTime)"
        }
        
        // Return the completed cell
        return cell
    }
    
    // Get the data from Firebase
    func retrieveData(day : String) {
        
        // Define the reference for our database by the given day
        let ref = Database.database().reference().child("Schedule").child(day)
     
        // View and parse the data
        ref.observeSingleEvent(of: .value) { (snapshot) in
            
            // Remove anything in the array, since we are totally updating it!
            self.schedule.removeAll()
            
            // Validate
            guard let values = snapshot.value as? [NSDictionary] else { return }
           
            // Loop through items, and save them as objects of the custom class Event
            for item in values {
                if item["name"] != nil {
                    let event = Event()
                    event.name = item["name"]! as! String
                    event.description = item["description"]! as! String
                    event.location = item["location"]! as! String
                    event.startTime = item["start-time"] as! String
                    event.endTime = item["end-time"] as! String
                    
                    // Add the object to our array
                    self.schedule.append(event)
                }
                else {
                    print("Something went wrong loading the schedule data")
                }
            }
            // Reload our table with updated data
            self.tableView.reloadData()
        }
    }
    
}
