//
//  EditProfileVC.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit
import Firebase

// Edit Profile Page
class EditProfileVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // Outlets & Global Variables
    @IBOutlet weak var profilePic: UIImageView!
    @IBOutlet weak var bioField: UITextView!
    @IBOutlet weak var social: UITextField!
    @IBOutlet weak var linkedin: UITextField!
    
    let picker = UIImagePickerController()
    var userStorage: StorageReference!
    
    var imageURL : URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set delegate
        picker.delegate = self
       
    }
    
    // Add profile picture by presenting picture selector
    @IBAction func addProfilePic(_ sender: Any) {
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    // When the image is selected, store it and update UI
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        // Validate & update UI
        if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            self.profilePic.image = image
            profilePic.layer.cornerRadius = profilePic.frame.size.width/2
            profilePic.clipsToBounds = true
            profilePic.contentMode = .scaleAspectFill
        }
        
        // Let's get the image url, will be saved later
        if let url = info[UIImagePickerController.InfoKey.imageURL] as? URL {
            imageURL = url
        }
        
        self.dismiss(animated:true, completion: nil)
    }
    
    // Save all edits
    @IBAction func savePressed(_ sender: Any) {
        
        // Validate
        guard let bio = bioField.text, let social = social.text, let linkedin = linkedin.text else { return}
                    
        // Pathway to update info
        let userID = Auth.auth().currentUser?.uid
        let userRef = Database.database().reference().child("users").child(userID!).child("personalInfo")
        
        // Changes
        let updatedDictionary = ["bio": bio, "social": social, "linkedin": linkedin]
        
        // Store changes in pathway
        userRef.updateChildValues(updatedDictionary)
        
        // Upload image to Firebase Storage
        if let imageURLCheck = imageURL {
            uploadImage(url: imageURLCheck, address: userID!)
        }
        else {
            //no image to update
        }
        
        // Return to app
        self.performSegue(withIdentifier: "goToProfile", sender: self)
    }
    
    // Sending the data to Firebase Storage
    func uploadImage(url: URL, address: String) {
        let fileName = "profileImage"
        userStorage =  Storage.storage().reference().child("displayUsers").child(address).child(fileName)
        userStorage.putFile(from: url)
    }

}
