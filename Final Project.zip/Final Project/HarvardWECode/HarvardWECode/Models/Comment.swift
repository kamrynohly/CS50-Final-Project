//
//  Comment.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/7/21.
//

import Foundation
import UIKit
import Firebase

// Custom Comment Class
class Comment {
    
    var content : String
    var name : String
    var photoRef : StorageReference
    
    // Must have all 3
    init(contentInput: String, nameInput: String, userPic: StorageReference) {
        content = contentInput
        name = nameInput
        photoRef = userPic
    }
    
}


