//
//  event.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import Foundation

// Custom Event Class
class Event {
    
    var name = ""
    var description = ""
    var location = ""
    var startTime = ""
    var endTime = ""
    
}
