//
//  Interaction.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import Foundation

// Custom Interaction Class
class Interaction {
    var name = ""
    var content = ""
    var comments = [String]()
    var firebaseID = ""
    
    // Must initialize it with these values
    init(nameInput : String, contentInput: String){
        name = nameInput
        content = contentInput
    }
}
