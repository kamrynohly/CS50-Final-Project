//
//  ScheduleCellTableViewCell.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit

// Custom Class to Store Events
class ScheduleCellTableViewCell: UITableViewCell {
    
    // Outlets to access/update on the screen
    @IBOutlet weak var location: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var time: UILabel!
    
    // Default Swift Code (auto-loads)
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
