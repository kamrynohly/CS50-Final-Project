//
//  CommentCell.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit
import Firebase

// Custom Class for Comments in InteractVC
class CommentCell: UITableViewCell {

    // Defining outlets
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    @IBOutlet weak var contentLabel: UILabel!
    
    var userID: String!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    // Uses FirebaseUI to add image without downloading it to user's phone + design
    func addImage(reference: StorageReference) {
        profilePic.sd_setImage(with: reference, placeholderImage: UIImage(named: ""))
        profilePic.layer.cornerRadius = profilePic.frame.height/2
        profilePic.clipsToBounds = true
        profilePic.contentMode = .scaleAspectFill
   }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
