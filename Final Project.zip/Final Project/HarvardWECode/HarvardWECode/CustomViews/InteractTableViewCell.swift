//
//  InteractTableViewCell.swift
//  HarvardWECode
//
//  Updated by Kamryn Ohly on 12/6/21.
//

import UIKit

// Custom class for user-generated content
class InteractTableViewCell: UITableViewCell {
    
    // Outlets to access/update on the screen
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var commentButton: UIButton!
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var viewOfCell: UIView!
    
    // Defining that the button will have an action added to it when an object of the class is initialized
    // I add a function for the button in InteractVC
    var addCommentButtonAction : (() -> ())?

    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Defining the button to have a target
        self.commentButton.addTarget(self, action: #selector(addComment(_:)), for: .touchUpInside)
        
        // Make the cell have rounded corners and a border
        viewOfCell.layer.cornerRadius = 25
        viewOfCell.layer.borderWidth = 2
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // Put space between cells
        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    // Action defined in-depth in InteractVC
    @IBAction func addComment(_ sender: Any) {
        addCommentButtonAction?()
    }
    
}
